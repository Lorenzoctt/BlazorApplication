﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApplication.Data
{
    public class Reperto
    {
        [Key]
        public int ID_reperto { get; set; }

        public string Descrizione { get; set; }


        [Required(ErrorMessage = "devi effettuare la selezione")]
        public int ID_periodo { get; set; }

        [Required(ErrorMessage = "devi effettuare la selezione")]
        public int Id_tipologia { get; set; }

        public string Periodo { get; set; }  // DA RIMUOVERE

        public string Tipologia { get; set; } // DA RIMUOVERE

    }
}
