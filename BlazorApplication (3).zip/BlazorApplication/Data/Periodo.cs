﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace BlazorApplication.Data
{
    public class Periodo
    {
        [Key]
        public int ID_periodo { get; set; }

        public string Descrizione { get; set; }
    }
}
